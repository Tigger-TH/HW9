﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class AddressBook : Form
    {
        public AddressBook()
        {
            InitializeComponent();
        }
        private string currentDataFilePath = Path.Combine(Application.StartupPath, "contacts.csv");
        

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label23_Click(object sender, EventArgs e)
        {

        }

        private void textAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Address Book";

            cboTitle.Items.Clear();
            cboTitle.Items.AddRange(new object[]
            {
            "นาย",
            "นาง",
            "นางสาว",
            "เด็กชาย",
            "เด็กหญิง"
            });

            cboGender.Items.Clear();
            cboGender.Items.AddRange(new object[]
            {
            "ชาย",
            "หญิง"
            });

            cboTitle.DropDownStyle = ComboBoxStyle.DropDownList;
            cboGender.DropDownStyle = ComboBoxStyle.DropDownList;

            dtpBirthDate.MaxDate = DateTime.Today;
            dtpBirthDate.Value = DateTime.Today;

            textAge.ReadOnly = true;
            textAge.TabStop = false;

            errorProvider1.BlinkStyle =
                ErrorBlinkStyle.NeverBlink;
        }

        // Event 2: SelectedIndexChanged
        private void cboTitle_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTitle.Text == "นาย")
            {
                cboGender.SelectedItem = "ชาย";
            }
            else if (cboTitle.Text == "นาง" ||
                     cboTitle.Text == "นางสาว")
            {
                cboGender.SelectedItem = "หญิง";
            }
            else
            {
                cboGender.SelectedItem = "ไม่ระบุ";
            }
        }

        // Event 3: ValueChanged
        private void dtpBirthDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime birthDate = dtpBirthDate.Value.Date;
            DateTime today = DateTime.Today;

            int age = today.Year - birthDate.Year;

            if (birthDate > today.AddYears(-age))
            {
                age--;
            }

            textAge.Text = Math.Max(age, 0).ToString();
        }

        // Event 4: KeyPress
        // ใช้ Event เดียวร่วมกันกับโทรศัพท์และรหัสไปรษณีย์
        private void NumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            // อนุญาตเฉพาะตัวเลขและปุ่มควบคุม เช่น Backspace
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // Event 5: TextChanged
        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();

            if (email == "")
            {
                errorProvider1.SetError(txtEmail, "");
                return;
            }

            if (!IsValidEmail(email))
            {
                errorProvider1.SetError(txtEmail, "รูปแบบอีเมลไม่ถูกต้อง");
            }
            else
            {
                errorProvider1.SetError(txtEmail, "");
            }
        }

        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        // Event 6: Click - Save
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!CheckRequiredFields())
            {
                MessageBox.Show(
                    "กรุณากรอกข้อมูลให้ครบถ้วน",
                    "ข้อมูลไม่ครบ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }
            ;

            if (!ValidateInput())
            {
                MessageBox.Show(
                    "กรุณาตรวจสอบข้อมูลที่กรอก",
                    "ข้อมูลไม่ถูกต้อง",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            try
            {
                string filePath = Path.Combine(
                    Application.StartupPath,
                    "contacts.csv");

                bool createHeader = !File.Exists(filePath);

                StringBuilder output = new StringBuilder();

                if (createHeader)
                {
                    output.AppendLine(
                        "Title,FirstName,LastName,Nickname," +
                        "BirthDate,Gender,Age,Phone," +
                        "AlternatePhone,Email,AlternateEmail," +
                        "Company,JobTitle,Country,HouseNumber," +
                        "Building,Street,SubDistrict,District," +
                        "Province,PostalCode");
                }

                string[] values =
                {
                cboTitle.Text,
                txtFirstName.Text.Trim(),
                txtLastName.Text.Trim(),
                txtNickname.Text.Trim(),
                dtpBirthDate.Value.ToString("yyyy-MM-dd"),
                cboGender.Text,
                textAge.Text,
                txtPhone.Text.Trim(),
                txtAlternatePhone.Text.Trim(),
                txtEmail.Text.Trim(),
                txtAlternateEmail.Text.Trim(),
                txtCompany.Text.Trim(),
                txtJobTitle.Text.Trim(),
                txtCountry.Text.Trim(),
                txtHouseNumber.Text.Trim(),
                txtBuilding.Text.Trim(),
                txtStreet.Text.Trim(),
                txtSubDistrict.Text.Trim(),
                txtDistrict.Text.Trim(),
                txtProvince.Text.Trim(),
                txtPostalCode.Text.Trim()
            };

                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = EscapeCsv(values[i]);
                }

                output.AppendLine(string.Join(",", values));

                File.AppendAllText(
                    filePath,
                    output.ToString(),
                    new UTF8Encoding(true));

                MessageBox.Show(
                    "บันทึกข้อมูลเรียบร้อยแล้ว\n\n" +
                    "ไฟล์ถูกบันทึกไว้ที่:\n" + filePath,
                    "บันทึกสำเร็จ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ไม่สามารถบันทึกข้อมูลได้\n" + ex.Message, "เกิดข้อผิดพลาด", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private bool ValidateInput()
        {
            errorProvider1.Clear();

            bool isValid = true;

            if (string.IsNullOrWhiteSpace(
                txtFirstName.Text))
            {
                errorProvider1.SetError(txtFirstName, "กรุณากรอกชื่อ");

                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(
                txtLastName.Text))
            {
                errorProvider1.SetError(txtLastName, "กรุณากรอกนามสกุล");

                isValid = false;
            }

            string phone = txtPhone.Text.Trim();

            if (!Regex.IsMatch(phone, @"^\d{9,10}$"))
            {
                errorProvider1.SetError(txtPhone, "เบอร์โทรศัพท์ต้องมี 9-10 หลัก");

                isValid = false;
            }

            string email = txtEmail.Text.Trim();

            if (!IsValidEmail(email))
            {
                errorProvider1.SetError(txtEmail, "รูปแบบอีเมลไม่ถูกต้อง");

                isValid = false;
            }

            string alternateEmail =
                txtAlternateEmail.Text.Trim();

            if (alternateEmail != "" && !IsValidEmail(alternateEmail))
            {
                errorProvider1.SetError(
                    txtAlternateEmail,
                    "รูปแบบอีเมลสำรองไม่ถูกต้อง");

                isValid = false;
            }

            string postalCode =
                txtPostalCode.Text.Trim();

            if (postalCode != "" &&
                !Regex.IsMatch(postalCode, @"^\d{5}$"))
            {
                errorProvider1.SetError(
                    txtPostalCode,
                    "รหัสไปรษณีย์ต้องมี 5 หลัก");

                isValid = false;
            }

            return isValid;
        }

        private string EscapeCsv(string value)
        {
            if (value == null)
            {
                value = "";
            }

            value = value.Replace("\"", "\"\"");

            return "\"" + value + "\"";
        }

        // Click - Clear
        private void btnClear_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "ต้องการล้างข้อมูลทั้งหมดหรือไม่?",
                "ยืนยันการล้างข้อมูล",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                ClearForm();
            }
        }

        private void ClearForm()
        {
            ClearControls(this);

            dtpBirthDate.Value = DateTime.Today;
            textAge.Clear();

            errorProvider1.Clear();
            txtFirstName.Focus();
        }

        private void ClearControls(Control parent)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textBox = (TextBox)control;
                    textBox.Clear();
                }
                else if (control is ComboBox)
                {
                    ComboBox comboBox = (ComboBox)control;
                    comboBox.SelectedIndex = -1;
                }

                if (control.HasChildren)
                {
                    ClearControls(control);
                }
            }
        }

        private void txtProvince_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnOpenContacts_Click(object sender, EventArgs e)
        {
            using (ContactsListForm contactsForm = new ContactsListForm())
            {
                contactsForm.ShowDialog(this);
            }
        }
        private void NameOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            // อนุญาตตัวอักษร ช่องว่าง เครื่องหมายขีด และปุ่มควบคุม เช่น Backspace
            if (char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private bool CheckRequiredFields()
        {
            errorProvider1.Clear();
            bool isValid = true;

            Control[] requiredControls =
            {
        cboTitle,
        txtFirstName,
        txtLastName,
        txtNickname,
        cboGender,
        txtPhone,
        txtEmail,
        txtCompany,
        txtJobTitle,
        txtCountry,
        txtHouseNumber,
        txtBuilding,
        txtStreet,
        txtSubDistrict,
        txtDistrict,
        txtProvince,
        txtPostalCode
    };

            foreach (Control control in requiredControls)
            {
                if (string.IsNullOrWhiteSpace(control.Text))
                {
                    errorProvider1.SetError(
                        control,
                        "กรุณากรอกข้อมูลช่องนี้");

                    isValid = false;
                }
            }

            return isValid;
        }

    }
}
