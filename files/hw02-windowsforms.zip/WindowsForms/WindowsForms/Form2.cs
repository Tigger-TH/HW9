﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class ContactsListForm : Form
    {
        public ContactsListForm()
        {
            InitializeComponent();
        }
        private DataTable contactsTable;
        private void dgvContacts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvContacts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvContacts.MultiSelect = true;
            dgvContacts.ReadOnly = true;
            dgvContacts.AllowUserToAddRows = false;
        }

        private void ContactsListForm_Load(object sender, EventArgs e)
        {
            LoadContactsFromCsv();
            dgvContacts.RowHeadersVisible = true;
            dgvContacts.RowHeadersWidth = 60;

            dgvContacts.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadContactsFromCsv();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private DataTable CreateContactsTable()
        {
            DataTable table = new DataTable();

            table.Columns.Add("คำนำหน้า");
            table.Columns.Add("ชื่อ");
            table.Columns.Add("นามสกุล");
            table.Columns.Add("ชื่อเล่น");
            table.Columns.Add("วันเกิด");
            table.Columns.Add("เพศ");
            table.Columns.Add("อายุ");
            table.Columns.Add("เบอร์โทรศัพท์");
            table.Columns.Add("เบอร์โทรศัพท์สำรอง");
            table.Columns.Add("อีเมล");
            table.Columns.Add("อีเมลสำรอง");
            table.Columns.Add("บริษัท");
            table.Columns.Add("ตำแหน่งงาน");
            table.Columns.Add("ประเทศ");
            table.Columns.Add("บ้านเลขที่");
            table.Columns.Add("หมู่บ้าน/อาคาร");
            table.Columns.Add("ถนน");
            table.Columns.Add("ตำบล/แขวง");
            table.Columns.Add("อำเภอ/เขต");
            table.Columns.Add("จังหวัด");
            table.Columns.Add("รหัสไปรษณีย์");

            return table;
        }

        private string GetFilePath()
        {
            return Path.Combine(
                Application.StartupPath,
                "contacts.csv");
        }
        private void LoadContactsFromCsv()
        {
            string filePath = GetFilePath();
            contactsTable = CreateContactsTable();

            if (!File.Exists(filePath))
            {
                dgvContacts.DataSource = contactsTable;

                MessageBox.Show(
                    "ยังไม่พบไฟล์ contacts.csv",
                    "ไม่พบข้อมูล",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            try
            {
                using (TextFieldParser parser =
                    new TextFieldParser(filePath, Encoding.UTF8, true))
                {
                    parser.TextFieldType = FieldType.Delimited;
                    parser.SetDelimiters(",");
                    parser.HasFieldsEnclosedInQuotes = true;
                    parser.TrimWhiteSpace = false;

                    // ข้ามหัวตาราง
                    if (!parser.EndOfData)
                    {
                        parser.ReadFields();
                    }

                    while (!parser.EndOfData)
                    {
                        string[] fields = parser.ReadFields();

                        if (fields != null &&
                            fields.Length == contactsTable.Columns.Count)
                        {
                            contactsTable.Rows.Add(fields);
                        }
                    }
                }

                dgvContacts.DataSource = contactsTable;

                dgvContacts.ReadOnly = true;
                dgvContacts.AllowUserToAddRows = false;
                dgvContacts.AllowUserToDeleteRows = false;
                dgvContacts.MultiSelect = false;
                dgvContacts.SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect;

                dgvContacts.AutoSizeColumnsMode =
                    DataGridViewAutoSizeColumnsMode.DisplayedCells;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "ไม่สามารถอ่านข้อมูลได้\n" + ex.Message,
                    "เกิดข้อผิดพลาด",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
        private void SaveTableToCsv()
        {
            string filePath = GetFilePath();

            StringBuilder output = new StringBuilder();

            // หัวคอลัมน์ต้องตรงกับไฟล์ที่ใช้บันทึกจาก Form หลัก
            output.AppendLine(
                "Title,FirstName,LastName,Nickname," +
                "BirthDate,Gender,Age,Phone," +
                "AlternatePhone,Email,AlternateEmail," +
                "Company,JobTitle,Country,HouseNumber," +
                "Building,Street,SubDistrict,District," +
                "Province,PostalCode");

            foreach (DataRow row in contactsTable.Rows)
            {
                string[] values = new string[
                    contactsTable.Columns.Count];

                for (int i = 0; i < contactsTable.Columns.Count; i++)
                {
                    values[i] = EscapeCsv(row[i]?.ToString() ?? "");
                }

                output.AppendLine(string.Join(",", values));
            }

            File.WriteAllText(
                filePath,
                output.ToString(),
                new UTF8Encoding(true));
        }
        private void btnDeleteAll_Click(
    object sender,
    EventArgs e)
        {
            if (contactsTable == null ||
                contactsTable.Rows.Count == 0)
            {
                MessageBox.Show(
                    "ไม่มีข้อมูลให้ลบ",
                    "ไม่พบข้อมูล",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            DialogResult result = MessageBox.Show(
                "ต้องการลบข้อมูลผู้ติดต่อทั้งหมดหรือไม่?\n\n" +
                "ข้อมูลที่ลบแล้วไม่สามารถกู้คืนได้",
                "ยืนยันการลบข้อมูลทั้งหมด",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (result != DialogResult.Yes)
            {
                return;
            }

            try
            {
                contactsTable.Rows.Clear();

                SaveTableToCsv();

                MessageBox.Show(
                    "ลบข้อมูลทั้งหมดเรียบร้อยแล้ว",
                    "ลบสำเร็จ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "ไม่สามารถลบข้อมูลทั้งหมดได้\n" +
                    ex.Message,
                    "เกิดข้อผิดพลาด",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                LoadContactsFromCsv();
            }
        }

        private string EscapeCsv(string value)
        {
            if (value == null)
            {
                value = "";
            }

            // ถ้ามีเครื่องหมาย " ให้เปลี่ยนเป็น ""
            value = value.Replace("\"", "\"\"");

            // ครอบข้อมูลแต่ละช่องด้วย "
            return "\"" + value + "\"";
        }

        private void btnDeleteSelected_Click(object sender, EventArgs e)
        {
            if (dgvContacts.SelectedRows.Count == 0)
            {
                MessageBox.Show(
                    "กรุณาเลือกรายการที่ต้องการลบ",
                    "ยังไม่ได้เลือกรายการ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            DataGridViewRow selectedRow =
                dgvContacts.SelectedRows[0];

            DataRowView rowView =
                selectedRow.DataBoundItem as DataRowView;

            if (rowView == null)
            {
                MessageBox.Show(
                    "ไม่สามารถอ่านข้อมูลแถวที่เลือกได้",
                    "เกิดข้อผิดพลาด",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return;
            }

            string contactName =
                rowView["ชื่อ"]?.ToString() + " " +
                rowView["นามสกุล"]?.ToString();

            DialogResult result = MessageBox.Show(
                "ต้องการลบข้อมูลของ\n" +
                contactName.Trim() +
                "\nหรือไม่?",
                "ยืนยันการลบ",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result != DialogResult.Yes)
            {
                return;
            }

            try
            {
                contactsTable.Rows.Remove(rowView.Row);

                SaveTableToCsv();

                MessageBox.Show(
                    "ลบข้อมูลเรียบร้อยแล้ว",
                    "ลบสำเร็จ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "ไม่สามารถลบข้อมูลได้\n" +
                    ex.Message,
                    "เกิดข้อผิดพลาด",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                // โหลดข้อมูลจากไฟล์ใหม่ เผื่อ DataTable เปลี่ยนไปแล้ว
                LoadContactsFromCsv();
            }
        }
    }
}
